import db from "../config/db.js"

export const makePayment = async (req, res, next) => {
    try {
        const user_id = req.user.id
        const { order_id } = req.body

        const order = await db.query("SELECT * FROM orders WHERE id=$1 AND user_id=$2", [order_id, user_id])
        if (order.rows.length === 0) return next({ status: 404, message: "Order topilmadi" })

        await db.query(
            "INSERT INTO payments(order_id, amount, status) VALUES($1,$2,'paid')",
            [order_id, order.rows[0].total_price]
        )

        await db.query(
            "UPDATE orders SET status='paid' WHERE id=$1",
            [order_id]
        )

        res.json({message: "To'lov muvaffaqiyatli amalga oshdi" })
    } catch (err) {
        next(err)
    }
}