import db from "../config/db.js"

export const getBooks = async (req, res, next) => {
    try {
        const books = await pool.query("SELECT * FROM books")
        res.json({books: books.rows })
    } catch (err) {
        next(err)
    }
}

export const addBook = async (req, res, next) => {
    try {
        const { title, price } = req.body
        if (!title || !price) return next({ status: 400, message: "Title va price kerak" })

        await db.query("INSERT INTO books(title, price) VALUES($1,$2)", [title, price])
        res.json({ essage: "Kitob qo'shildi" })
    } catch (err) {
        next(err)
    }
}