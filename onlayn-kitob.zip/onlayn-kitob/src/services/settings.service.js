import db from "../config/db.js"

export const getSettings = async (req, res, next) => {
    try {
        const user_id = req.user.id
        const settings = await db.query(
            "SELECT theme, notifications, language FROM user_settings WHERE user_id=$1",
            [user_id]
        )

        if (settings.rows.length === 0) {
            await db.query(
                "INSERT INTO user_settings(user_id) VALUES($1)",
                [user_id]
            )
            return res.json({
                success: true,
                settings: {
                    theme: 'light',
                    notifications: true,
                    language: ['uzb', 'rus', 'eng']
                }
            })
        }

        res.json({settings: settings.rows[0] })
    } catch (err) {
        next(err)
    }
}

export const updateSettings = async (req, res, next) => {
    try {
        const user_id = req.user.id
        const { theme, notifications, language } = req.body

        await db.query(
            `UPDATE user_settings 
       SET theme=$1, notifications=$2, language=$3 
       WHERE user_id=$4`,
            [theme, notifications, language, user_id]
        )

        res.json({message: "Sozlamalar yangilandi" })
    } catch (err) {
        next(err)
    }
}