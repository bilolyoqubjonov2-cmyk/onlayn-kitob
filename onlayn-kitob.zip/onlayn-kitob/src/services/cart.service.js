import db from "../config/db.js"

export const addToCart = async (req, res, next) => {
    try {
        const user_id = req.user.id
        const { book_id, quantity } = req.body

        const book = await db.query("SELECT * FROM books WHERE id=$1", [book_id])
        if (book.rows.length === 0) return next({ status: 404, message: "Book topilmadi" })

        const existing = await pool.query("SELECT * FROM cart WHERE user_id=$1 AND book_id=$2", [user_id, book_id])

        if (existing.rows.length > 0) {
            await db.query(
                "UPDATE cart SET quantity = quantity + $1 WHERE user_id=$2 AND book_id=$3",
                [quantity || 1, user_id, book_id]
            )
        } else {
            await db.query("INSERT INTO cart(user_id, book_id, quantity) VALUES($1,$2,$3)", [user_id, book_id, quantity || 1])
        }

        res.json({ success: true, message: "Cartga qo‘shildi" })
    } catch (err) {
        next(err)
    }
}

export const getCart = async (req, res, next) => {
    try {
        const user_id = req.user.id
        const cart = await db.query(
            `SELECT c.id, b.title, b.price, c.quantity
       FROM cart c JOIN books b ON c.book_id=b.id
       WHERE c.user_id=$1`,
            [user_id]
        )
        res.json({ success: true, cart: cart.rows })
    } catch (err) {
        next(err)
    }
}

export const removeFromCart = async (req, res, next) => {
    try {
        const user_id = req.user.id
        const { book_id } = req.body
        await db.query("DELETE FROM cart WHERE user_id=$1 AND book_id=$2", [user_id, book_id])
        res.json({message: "Cartdan o'chirildi" })
    } catch (err) {
        next(err)
    }
}

export const clearCart = async (req, res, next) => {
    try {
        const user_id = req.user.id
        await db.query("DELETE FROM cart WHERE user_id=$1", [user_id])
        res.json({message: "Cart tozalandi" })
    } catch (err) {
        next(err)
    }
}