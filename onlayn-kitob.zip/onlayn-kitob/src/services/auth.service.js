import db from "../config/db.js"

export const register = async (req, res, next) => {
    try {
        const { name, email, password } = req.body

        if (!name || !email || !password) {
            return next({ status: 400, message: "Barcha maydonlar to'ldirilishi kerak" })
        }

        const existing = await db.query("SELECT * FROM users WHERE email=$1", [email])
        if (existing.rows.length > 0) {
            return next({ status: 400, message: "Email allaqachon mavjud" })
        }

        await db.query(
            "INSERT INTO users(name,email,password) VALUES($1,$2,$3)",
            [name, email, password]
        )

        res.json({ message: "User ro'yxatdan o'tdi" })
    } catch (err) {
        next(err)
    }
}

export const login = async (req, res, next) => {
    try {
        const { email, password } = req.body

        const user = await db.query("SELECT * FROM users WHERE email=$1 AND password=$2", [email, password])

        if (user.rows.length === 0) {
            return next({ status: 401, message: "Email yoki parol noto'g'ri" })
        }

        res.json({ user: user.rows[0] })
    } catch (err) {
        next(err)
    }
}