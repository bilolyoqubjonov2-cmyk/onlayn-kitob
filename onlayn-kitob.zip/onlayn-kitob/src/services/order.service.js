import db from "../config/db.js"

export const createOrder = async (req, res, next) => {
    try {
        const user_id = req.user.id

        const cart = await db.query(
            "SELECT * FROM cart WHERE user_id=$1",
            [user_id]
        )
        if (cart.rows.length === 0) return next({ status: 400, message: "Cart bo'sh" })

        let total = 0
        for (let item of cart.rows) {
            const book = await db.query("SELECT * FROM books WHERE id=$1", [item.book_id])
            total += book.rows[0].price * item.quantity
        }

        const order = await db.query(
            "INSERT INTO orders(user_id, total_price) VALUES($1,$2) RETURNING id",
            [user_id, total]
        )
        const order_id = order.rows[0].id

        for (let item of cart.rows) {
            const book = await db.query("SELECT * FROM books WHERE id=$1", [item.book_id])
            await db.query(
                "INSERT INTO order_items(order_id, book_id, quantity, price) VALUES($1,$2,$3,$4)",
                [order_id, item.book_id, item.quantity, book.rows[0].price]
            )
        }

        await db.query("DELETE FROM cart WHERE user_id=$1", [user_id])

        res.json({message: "Order yaratildi", order_id })
    } catch (err) {
        next(err)
    }
}