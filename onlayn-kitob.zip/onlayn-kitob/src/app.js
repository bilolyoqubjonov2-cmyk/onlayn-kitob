import express from "express"
import settingsRoutes from "./routes/settings.routes.js"
import authRoutes from "./routes/auth.routes.js"
import bookRoutes from "./routes/book.routes.js"
import cartRoutes from "./routes/cart.routes.js"
import orderRoutes from "./routes/order.routes.js"
import paymentRoutes from "./routes/payment.routes.js"
import { errorMiddleware } from "./middlewares/error.middleware.js"

const app = express()
app.use(express.json())

app.use("/api/settings", settingsRoutes)
app.use("/api/auth", authRoutes)
app.use("/api/books", bookRoutes)
app.use("/api/cart", cartRoutes)
app.use("/api/orders", orderRoutes)
app.use("/api/payment", paymentRoutes)

app.use(errorMiddleware)

export default app