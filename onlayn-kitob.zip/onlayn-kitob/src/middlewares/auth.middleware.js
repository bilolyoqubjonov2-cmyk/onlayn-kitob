export const authMiddleware = (req, res, next) => {
    const userId = req.headers["user_id"]

    if (!userId) {
        return res.status(401).json({
            message: "Unauthorized! user_id header yuboring"
        })
    }

    req.user = { id: userId }
    next()
}