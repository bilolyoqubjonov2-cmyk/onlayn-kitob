import express from "express"
import { getBooks, addBook } from "../services/book.service.js"

const router = express.Router()

router.get("/", getBooks)
router.post("/add", addBook)

export default router