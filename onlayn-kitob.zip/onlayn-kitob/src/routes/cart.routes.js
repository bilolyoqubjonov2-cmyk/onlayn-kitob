import express from "express"
import { addToCart, getCart, removeFromCart, clearCart } from "../services/cart.service.js"
import { authMiddleware } from "../middlewares/auth.middleware.js"

const router = express.Router()

router.post("/add", authMiddleware, addToCart)
router.get("/", authMiddleware, getCart)
router.delete("/remove", authMiddleware, removeFromCart)
router.delete("/clear", authMiddleware, clearCart)

export default router