import express from "express"
import { makePayment } from "../services/payment.service.js"
import { authMiddleware } from "../middlewares/auth.middleware.js"

const router = express.Router()

router.post("/pay", authMiddleware, makePayment)

export default router