import express from "express"
import { getSettings, updateSettings } from "../services/settings.service.js"
import { authMiddleware } from "../middlewares/auth.middleware.js"

const router = express.Router()

// Sozlamalarni olish
router.get("/", authMiddleware, getSettings)

// Sozlamalarni yangilash
router.put("/", authMiddleware, updateSettings)

export default router