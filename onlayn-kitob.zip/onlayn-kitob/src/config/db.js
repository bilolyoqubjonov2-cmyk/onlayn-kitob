import {Pool} from "pg";

const db = new Pool({
    host : "localhost",
    user : "postgres",
    port : 5432,
    password : "1234",
    database : "dokon"
});

export default db